# Jogo-do-Trex
Pule ou Toque para jogar
